
#--------------------------------------------------------------------------------------#

#   REPLICATION CODE                               
#   Trade agreements and the design of democracy-related provisions (TRADEM): The creation of a new data set
#   Manfred Elsig, Kirthana Ganeson, Andrew Lugg & Marine Roux
#   April 2026


#   NOTE: This script is organized in three parts:
#   (1) Set up the environment, set working directory and load libraries
#   (2) Descriptive charts 
#   (3) Regression analysis 



#--------------------------------------------------------------------------------------#


#-----                       PART 1: SET UP ENVIRONMENT                              ----


#--------------------------------------------------------------------------------------#


#         Change working directory here: 

setwd("")

#             Load libraries:

library(tidyverse)
library(readxl)
library(MASS)
library(lmtest)
library(conflicted)
library(broom)

conflict_prefer("select", "dplyr")
conflict_prefer("filter", "dplyr")


#                Load data


# Country-level data (for some country-level descriptive statistics):
load("data_country_level.RData")


# Treaty-level data (for treaty-level descriptive statistics + regressions):
load("data_treaty_level.RData")



#--------------------------------------------------------------------------------------#


#-----                       PART 2: DESCRIPTIVE STATISTICS                         ----


#--------------------------------------------------------------------------------------#




#-------------------------------------------------------------------------------------#
####                           FIGURE 2: BY CATEGORY                               ####
#-------------------------------------------------------------------------------------#

  
chart_by_category <- treaty_data  %>% 
  
  drop_na(tradem_index) %>% # remove observations for which there is no information on dem prov 
  
  select(number, contains("index")) %>% 
  select(-c(depth_index, tradem_index)) %>% # remove aggregated indices that are not of interest for this chart
  
  pivot_longer(-c(number), names_to = "category", values_to = "value") %>% 
  
  mutate(category = case_when(
    
    category == "democracypromotion_index" ~ "Democracy promotion",
    category == "general_index" ~ "General objectives",
    category == "transparency_index" ~ "Transparency",
    category == "policyspace_index" ~ "Policy space",
    category == "individualrights_index" ~ "Individual rights",
    category == "stakeholderparticipation_index" ~ "Stakeholder participation",
    TRUE ~ as.character(NA))) %>% 
  
  mutate(category = factor(category, 
                           levels = c("Policy space", "Transparency", "Stakeholder participation",
                                      "Individual rights", "Democracy promotion", "General objectives"))) %>%   # Reorder the levels
  group_by(category, value) %>%
  summarize(count = n()) %>% 
  ungroup() %>% 
  
  mutate(value = case_when(
    
    value == 0 ~ "None",
    value == 1 ~ "Shallow",
    value == 2 ~ "Comprehensive")) %>% 
  
  
  mutate(value = factor(value, 
                           levels = c("Comprehensive", "Shallow", "None"))) %>%   # Reorder the levels
  
  ggplot() + 
  
  geom_col(aes(x = category, y = count, group = value, fill = value)) + 
  coord_flip() +
  theme_bw() +
  theme(#axis.text.x = element_text(angle = 45, hjust=1),
    plot.title = element_text(size = 70, face = "bold", margin=margin(0,0,30,0), hjust = 0.5),
    axis.text=element_text(size=50, colour = "black"),
    axis.title=element_text(size=50, colour = "black"),
    legend.position = "bottom",
    legend.text = element_text(size = 50),
    legend.title = element_blank()) +
  scale_fill_manual(values = c("Shallow" = "darkgrey", "Comprehensive"="black", "None" = "lightgrey"),
                    guide = guide_legend(reverse = TRUE)) +
  labs(y = "Number of PTAs", x = "", title = "Number of PTAs by type \nof democracy-related provisions")


chart_by_category





#-------------------------------------------------------------------------------------#
####                           FIGURE 3: BY DECADE                                 ####
#-------------------------------------------------------------------------------------#



disaggregated_by_decade <- treaty_data %>% 
  
  drop_na(tradem_index) %>% # remove observations for which there is no information on dem prov 
  
  # identify decades 
  mutate(year_character = as.character(year)) %>%  # temporarily create var to create decade variable
  mutate(decade = case_when(
    startsWith(year_character, "194") == TRUE ~ "1948-1959",
    startsWith(year_character, "195") == TRUE  ~ "1948-1959",
    startsWith(year_character, "196") == TRUE  ~ "1960-1969",
    startsWith(year_character, "197") == TRUE  ~ "1970-1979",
    startsWith(year_character, "198") == TRUE  ~ "1980-1989",
    startsWith(year_character, "199") == TRUE  ~ "1990-1999",
    startsWith(year_character, "200") == TRUE  ~ "2000-2009",
    startsWith(year_character, "201") == TRUE  ~ "2010-2021",
    startsWith(year_character, "202") == TRUE  ~ "2010-2021",
    TRUE ~ as.character(NA)
  )) %>% 
  
  dplyr::select(-year_character) %>% 
  
  select(number, contains("index"), decade) %>% 
  #select(-depth_index) %>% 
  
  pivot_longer(-c(number, decade), names_to = "category", values_to = "value") %>% 
  
  mutate(category = case_when(
    
    category == "democracypromotion_index" ~ "Democracy promotion",
    category == "general_index" ~ "General objectives",
    category == "transparency_index" ~ "Transparency",
    category == "policyspace_index" ~ "Policy space",
    category == "individualrights_index" ~ "Individual rights",
    category == "stakeholderparticipation_index" ~ "Stakeholder participation",
    TRUE ~ as.character(NA))) %>% 
  
  mutate(category = factor(category, 
                           levels = c("General objectives", "Democracy promotion", "Individual rights",
                                      "Stakeholder participation", "Transparency", "Policy space"))) %>%  # Reorder the levels
  
  group_by(decade, category) %>%
  summarize(mean_by_decade_category = mean(value)) %>%
  ungroup() %>%
  
  drop_na(decade, category) %>% 
  
  ggplot(aes(x = decade, y = mean_by_decade_category, group = category, colour = category, shape = category)) + 
  geom_line(linewidth= 2) +
  geom_point(size = 4) +
  theme_bw() +
  theme(axis.text = element_text(size = 30, colour = "black"),
        axis.title = element_text(size = 30, colour = "black"),
        axis.title.y=element_text(size=30, colour = "black", margin = margin(r = 10)),
        legend.text = element_text(size = 30, colour = "black"),
        legend.title = element_text(size = 30, colour = "black"),
        legend.position = "bottom",
        legend.key.height = unit(3, "lines"),
        legend.key.width = unit(3, "cm")) +
  labs(x = "", y = "Mean category index (0-2)", colour = "Category index", shape = "Category index") +
  expand_limits(y = seq(0,2, by = 0.5))

disaggregated_by_decade




#-------------------------------------------------------------------------------------#
####                           FIGURE 4: MAP                                        ####
#-------------------------------------------------------------------------------------#


data_long <- data %>% 
  
  rename(country = country.name.en) %>% 
  
  # correct names when missing
  mutate(country = case_when(
    
    iso3n == 732 ~ "Western Sahara",
    iso3n == 500 ~ "Montserrat",
    iso3n == 184 ~ "Cook Islands",
    iso3n == 570 ~ "Niue",
    iso3n == 234 ~ "Faroe Islands",
    iso3n == 304 ~ "Greenland",
    iso3n == 900 ~ "Kosovo",
    country == "United Kingdom" ~ "UK",
    country == "United States" ~ "USA",
    country == "Bosnia & Herzegovina" ~ "Bosnia and Herzegovina",
    country == "Congo - Kinshasa" ~ "Democratic Republic of the Congo",
    country == "Congo - Brazzaville" ~ "Republic of Congo",
    country == "Czechia" ~ "Czech Republic",
    country == "Côte d’Ivoire" ~ "Ivory Coast", 
    country == "Eswatini" ~ "Swaziland",
    country == "Micronesia (Federated States of)" ~ "Micronesia",
    country == "Myanmar (Burma)" ~ "Myanmar", 
    country == "Palestinian Territories" ~ "Palestine",
    country == "St. Kitts & Nevis" ~ "Saint Kitts",
    country == "St. Lucia" ~ "Saint Lucia",
    country == "St. Vincent & Grenadines" ~ "Saint Vincent",
    country == "São Tomé & Príncipe" ~ "Sao Tome and Principe",
    country == "Hong Kong SAR China" ~ "Macao",
    TRUE ~ as.character(country))) %>% 
  
  # create dummy whether signed base provisions or not
  mutate(signed_tradem_index = case_when(
    
    tradem_index > 0 ~ 1,
    tradem_index == 0 ~ 0,
    TRUE ~ as.numeric(NA))) %>% 
  
  group_by(country) %>% 
  summarize(sum_tradem_index_country = sum(signed_tradem_index, na.rm = T)) %>% 
  ungroup()


# Get map data and merge with dataset 
world_map <- map_data("world")

# Clean country names to match (if necessary)
world_map$region <- as.character(world_map$region)

# Merge data
map_data <- world_map %>%
  left_join(data_long, by = c("region" = "country"))

# Chart baseline provisions 

ggplot(map_data, aes(x = long, y = lat, group = group, fill = sum_tradem_index_country)) +
  geom_polygon(color = "black") +
  coord_fixed(1.2) +
  scale_fill_gradient(low = "lightblue", high = "darkblue", na.value = "white") +
  labs(fill = "", x = "", y = "", title = "Number of PTAs with democracy-related provisions\nby country") +
  theme_minimal() +
  theme(axis.text = element_blank(),
        axis.ticks = element_blank(),
        plot.title = element_text(margin=margin(0,0,30,0), hjust = 0.5, size = 70, face = "bold"),
        legend.position = "bottom",
        legend.text = element_text(size = 30),
        legend.title = element_text(size = 30),
        legend.key.height = unit(2, "cm"),
        legend.key.width = unit(2, "cm"))




#-------------------------------------------------------------------------------------#
####                           FIGURE 5: BY REGION                                  ####
#-------------------------------------------------------------------------------------#


by_region_facet <-  data %>% 
  
  # identify decades 
  mutate(year_character = as.character(year)) %>%  # temporarily create var to create decade variable
  mutate(decade = case_when(
    startsWith(year_character, "194") == TRUE ~ "1948-1959",
    startsWith(year_character, "195") == TRUE  ~ "1948-1959",
    startsWith(year_character, "196") == TRUE  ~ "1960-1969",
    startsWith(year_character, "197") == TRUE  ~ "1970-1979",
    startsWith(year_character, "198") == TRUE  ~ "1980-1989",
    startsWith(year_character, "199") == TRUE  ~ "1990-1999",
    startsWith(year_character, "200") == TRUE  ~ "2000-2009",
    startsWith(year_character, "201") == TRUE  ~ "2010-2021",
    startsWith(year_character, "202") == TRUE  ~ "2010-2021",
    TRUE ~ as.character(NA)
  )) %>% 
  
  dplyr::select(-year_character) %>% 
  
  group_by(decade, regioncon) %>%
  mutate(mean_tradem = mean(tradem_index)) %>%
  ungroup() %>%
  
  group_by(decade, iso3n) %>%
  mutate(mean_country = mean(tradem_index)) %>%
  ungroup() %>%
  
  drop_na(decade) %>% 
  
  ggplot() + 
  geom_jitter(aes(x = decade, y = mean_country), size = 1, colour = "grey") +
  geom_line(aes(x = decade, y = mean_tradem, group = regioncon, colour = regioncon),linewidth = 2) +
  
  theme_bw() +
  
  theme(plot.title = element_text(size = 70, face = "bold", margin=margin(0,0,30,0), hjust = 0.5),
        axis.text = element_text(size = 30, colour = "black"),
        axis.text.x = element_text(angle = 90, vjust = 0.5),
        axis.title = element_text(size = 30, colour = "black"),
        axis.title.y=element_text(size=30, colour = "black", margin = margin(r = 10)),
        legend.text = element_text(size = 30, colour = "black"),
        legend.title = element_text(size = 30, colour = "black"),
        legend.position = "bottom",
        legend.key.height = unit(3, "lines"),
        legend.key.width = unit(3, "cm"),
        strip.text = element_text(size = 30)) +
  
  labs(x = "", y = "TRADEM index (0-6)", colour = "", shape = "") +
  expand_limits(y = seq(0,6, by = 0.5)) +
  
  facet_wrap(~regioncon)

by_region_facet



#-------------------------------------------------------------------------------------#
####                           FIGURE 6: BY REGIME TYPE                             ####
#-------------------------------------------------------------------------------------#


by_share_democratic_members <- data %>% 
  
  mutate(regime = case_when(
    v2x_regime %in% c(0,1) ~ 0,
    v2x_regime %in% c(2,3) ~ 1,
    TRUE ~ as.numeric(NA)
  )) %>% 
  
  group_by(number) %>% 
  mutate(n_members = n()) %>% 
  mutate(n_dem_members = sum(regime)) %>% 
  mutate(mean_regime = mean(regime)) %>% 
  ungroup() %>% 
  
  mutate(share_dem_members = n_dem_members/n_members) %>% 
  select(number, share_dem_members, tradem_index, mean_regime) %>% 
  unique() %>% 
  
  mutate(pta_regime_type = case_when(
    
    mean_regime == 0 ~ "Autocratic",
    mean_regime > 0 & mean_regime < 1 ~ "Mixed",
    mean_regime == 1 ~ "Democratic",
    TRUE ~ as.character(NA))) %>% 
  
  ggplot(aes(x = as.factor(tradem_index), y = share_dem_members)) +
  geom_boxplot(size = 1.5) +
  theme_bw() + 
  labs(y = "Share of democratic PTA members", x = "TRADEM index (0-6)") +
  theme(axis.text=element_text(size=30, color = "black"),
        axis.title=element_text(size=30, color = "black"),
        axis.title.y = element_text(margin = margin(r = 10), size = 30),
        axis.title.x = element_text(margin = margin(t = 10), size = 30)) 

by_share_democratic_members 
 


### ROBUSTNESS CHECKS FOR FIGURE 6 (Online appendix 8) ###

# Figure A6: Average democracy score of members by PTA (V-DEM)

by_avg_vdem_score <-  data %>% 
  
  mutate(regime = case_when(
    v2x_regime %in% c(0,1) ~ 0,
    v2x_regime %in% c(2,3) ~ 1,
    TRUE ~ as.numeric(NA)
  )) %>% 
  
  group_by(number) %>% 
  mutate(n_members = n()) %>% 
  mutate(n_dem_members = sum(regime)) %>% 
  mutate(mean_regime = mean(regime)) %>% 
  ungroup() %>% 
  
  mutate(share_dem_members = n_dem_members/n_members) %>% 
  select(number, share_dem_members, tradem_index, mean_regime) %>% 
  unique() %>% 
  
  mutate(pta_regime_type = case_when(
    
    mean_regime == 0 ~ "Autocratic",
    mean_regime > 0 & mean_regime < 1 ~ "Mixed",
    mean_regime == 1 ~ "Democratic",
    TRUE ~ as.character(NA))) %>% 

  drop_na(pta_regime_type) %>%
  
  ggplot(aes(x = fct_reorder(pta_regime_type, tradem_index), y = tradem_index)) + 
  geom_boxplot(size = 1.5)+
  theme_bw() + 
  labs(x = "PTA regime type", y = "TRADEM index (0-6)") +
  theme(axis.text=element_text(size=30, color = "black"),
        axis.title=element_text(size=30, color = "black"),
        axis.title.y = element_text(margin = margin(r = 10), size = 30),
        axis.title.x = element_text(margin = margin(t = 10), size = 30)) # +
  #stat_compare_means() # to use this command, load package ggpubr, this enables to test the significant differences in means.

by_avg_vdem_score

# Figure A7: Average democracy score of members by PTA (Polity project)

by_avg_polity_score <- data %>% 
  
  # remove Malta because otherwise EU agreements starting from Malta accession always score NA,
  # as there is missing data for Malta. Removing Malta does not introduce particularly a bias, as 
  # the polity score is not expected to be substantially lower/higher to the average Polity score
  # of other EU members. Additionally, even if it was it could be considered as an outlier as Malta
  # since its accession represent only one country out of maximum 19 members (in 2004) and 27 members
  # nowadays..
  filter(!(iso3n == 470)) %>% 
  
  mutate(polity20 = polity2 + 10) %>% 
  
  group_by(number) %>% 
  
  mutate(mean_tradem = mean(tradem_index),
         mean_polity20 = mean(polity20)) %>% 
  
  ungroup() %>% 
  
  select(number, mean_tradem, mean_polity20, depth_index) %>% 
  
  unique() %>% 
  
  mutate(regime_type = case_when(
    
    mean_polity20 <= 5 ~ "Autocratic",
    mean_polity20 > 5 & mean_polity20 < 16 ~ "Mixed",
    mean_polity20 >= 16 ~ "Democratic",
    TRUE ~ as.character(NA))) %>% 
  
  drop_na(regime_type) %>% 
  
  ggplot(aes(x = fct_reorder(regime_type, mean_tradem), y = mean_tradem)) + 
  geom_boxplot(size = 1.5)+
  theme_bw() + 
  labs(x = "PTA regime type", y = "TRADEM index (0-6)") +
  theme(axis.text=element_text(size=30, color = "black"),
        axis.title=element_text(size=30, color = "black"),
        axis.title.y = element_text(margin = margin(r = 10), size = 30),
        axis.title.x = element_text(margin = margin(t = 10), size = 30)) #+
  #stat_compare_means() # to use this command, load package ggpubr, this enables to test the significant differences in means.


by_avg_polity_score



#--------------------------------------------------------------------------------------#


#-----                           PART 3: REGRESSIONS                                ----


#--------------------------------------------------------------------------------------#



#-------------------------------------------------------------------------------------#

####                          TABLE 5: DV = TRADEM INDEX                            ####

#-------------------------------------------------------------------------------------#



model_base <- polr(as.factor(tradem_index) ~ share_dem_members + depth_index,
                   data = treaty_data,
                   method = c("logistic"))


model_add_gdppc <- polr(as.factor(tradem_index) ~ share_dem_members + 
                          depth_index + log(mean_gdppc),
                        data = treaty_data,
                        method = c("logistic"))

model_add_wto <- polr(as.factor(tradem_index) ~ share_dem_members + 
                        depth_index + log(mean_gdppc) + mean_wto_gatt,
                      data = treaty_data,
                      method = c("logistic")) 

model_add_gravity <- polr(as.factor(tradem_index) ~ share_dem_members + 
                            depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                            mean_comleg_posttrans ,
                          data = treaty_data,
                          method = c("logistic")) 


model_add_exports <- polr(as.factor(tradem_index) ~ share_dem_members + 
                            depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                            mean_comleg_posttrans + log(mean_exports),
                          data = treaty_data,
                          method = c("logistic"))



coeftest(model_base)
coeftest(model_add_gdppc)
coeftest(model_add_wto)
coeftest(model_add_gravity)
coeftest(model_add_exports)



### GET N OBS

n_obs_base <- model_base %>% glance() %>% select(nobs) %>% mutate(model = "base")
n_obs_add_gdppc <- model_add_gdppc %>% glance() %>% select(nobs) %>% mutate(model = "add_gdppc")
n_obs_add_wto <- model_add_wto %>% glance() %>% select(nobs) %>% mutate(model = "add_wto")
n_obs_add_gravity <- model_add_gravity %>% glance() %>% select(nobs) %>% mutate(model = "add_gravity")
n_obs_add_exports <- model_add_exports %>% glance() %>% select(nobs) %>% mutate(model = "add_exports")


### GET MCFADDEN R SQUARED

model_null <- polr(as.factor(tradem_index) ~ 1, data = treaty_data,
                   method = c("logistic"))

mcfadden_base <- as.data.frame(list(mcfadden = round(1 - (logLik(model_base)/logLik(model_null)),2))) %>% mutate(model = "base")
mcfadden_add_gdppc <- as.data.frame(list(mcfadden = round(1 - (logLik(model_add_gdppc)/logLik(model_null)),2))) %>% mutate(model = "add_gdppc")
mcfadden_add_wto <- as.data.frame(list(mcfadden = round(1 - (logLik(model_add_wto)/logLik(model_null)),2))) %>% mutate(model = "add_wto")
mcfadden_add_gravity <- as.data.frame(list(mcfadden = round(1 - (logLik(model_add_gravity)/logLik(model_null)),2))) %>% mutate(model = "add_gravity")
mcfadden_add_exports <- as.data.frame(list(mcfadden = round(1 - (logLik(model_add_exports)/logLik(model_null)),2))) %>% mutate(model = "add_exports")


### PASTE ALL RESULTS

base <- model_base %>% tidy() %>% mutate(model = "base") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_base, by = "model") %>% left_join(mcfadden_base, by = "model")
add_gdppc <- model_add_gdppc %>% tidy() %>% mutate(model = "add_gdppc") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(n_obs_add_gdppc, by = "model") %>% left_join(mcfadden_add_gdppc, by = "model")
add_wto <- model_add_wto %>% tidy() %>% mutate(model = "add_wto") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_add_wto, by = "model") %>% left_join(mcfadden_add_wto, by = "model")
add_gravity <- model_add_gravity %>% tidy() %>% mutate(model = "add_gravity") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_add_gravity, by = "model") %>% left_join(mcfadden_add_gravity, by = "model")
add_exports <- model_add_exports %>% tidy() %>% mutate(model = "add_exports") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_add_exports, by = "model") %>% left_join(mcfadden_add_exports, by = "model")

all_results <- rbind(base, add_gdppc, add_wto, add_gravity, add_exports)



#-------------------------------------------------------------------------------------#

####                    ROBUSTNESS CHECKS FOR TABLE 5                              ####

#-------------------------------------------------------------------------------------#



#### Table A1: Average liberal democracy measurement (instead of share of democratic members as IV) 


libdem_model_base <- polr(as.factor(tradem_index) ~ mean_v2x_libdem + depth_index,
                          data = treaty_data,
                          method = c("logistic"))


libdem_model_add_gdppc <- polr(as.factor(tradem_index) ~ mean_v2x_libdem + 
                                 depth_index + log(mean_gdppc),
                               data = treaty_data,
                               method = c("logistic"))

libdem_model_add_wto <- polr(as.factor(tradem_index) ~ mean_v2x_libdem + 
                               depth_index + log(mean_gdppc) + mean_wto_gatt,
                             data = treaty_data,
                             method = c("logistic")) 

libdem_model_add_gravity <- polr(as.factor(tradem_index) ~ mean_v2x_libdem + 
                                   depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                   mean_comleg_posttrans ,
                                 data = treaty_data,
                                 method = c("logistic")) 


libdem_model_add_exports <- polr(as.factor(tradem_index) ~ mean_v2x_libdem + 
                                   depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                   mean_comleg_posttrans + log(mean_exports),
                                 data = treaty_data,
                                 method = c("logistic"))

coeftest(libdem_model_base)
coeftest(libdem_model_add_gdppc)
coeftest(libdem_model_add_wto)
coeftest(libdem_model_add_gravity)
coeftest(libdem_model_add_exports)

### GET N OBS

libdem_n_obs_base <- libdem_model_base %>% glance() %>% select(nobs) %>% mutate(model = "base")
libdem_n_obs_add_gdppc <- libdem_model_add_gdppc %>% glance() %>% select(nobs) %>% mutate(model = "add_gdppc")
libdem_n_obs_add_wto <- libdem_model_add_wto %>% glance() %>% select(nobs) %>% mutate(model = "add_wto")
libdem_n_obs_add_gravity <- libdem_model_add_gravity %>% glance() %>% select(nobs) %>% mutate(model = "add_gravity")
libdem_n_obs_add_exports <- libdem_model_add_exports %>% glance() %>% select(nobs) %>% mutate(model = "add_exports")


### GET MCFADDEN R SQUARED

libdem_model_null <- polr(as.factor(tradem_index) ~ 1, data = treaty_data,
                          method = c("logistic"))

libdem_mcfadden_base <- as.data.frame(list(mcfadden = round(1 - (logLik(libdem_model_base)/logLik(libdem_model_null)),2))) %>% mutate(model = "base")
libdem_mcfadden_add_gdppc <- as.data.frame(list(mcfadden = round(1 - (logLik(libdem_model_add_gdppc)/logLik(libdem_model_null)),2))) %>% mutate(model = "add_gdppc")
libdem_mcfadden_add_wto <- as.data.frame(list(mcfadden = round(1 - (logLik(libdem_model_add_wto)/logLik(libdem_model_null)),2))) %>% mutate(model = "add_wto")
libdem_mcfadden_add_gravity <- as.data.frame(list(mcfadden = round(1 - (logLik(libdem_model_add_gravity)/logLik(libdem_model_null)),2))) %>% mutate(model = "add_gravity")
libdem_mcfadden_add_exports <- as.data.frame(list(mcfadden = round(1 - (logLik(libdem_model_add_exports)/logLik(libdem_model_null)),2))) %>% mutate(model = "add_exports")


### PASTE ALL RESULTS

libdem_base <- libdem_model_base %>% tidy() %>% mutate(model = "base") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_base, by = "model") %>% left_join(libdem_mcfadden_base, by = "model")
libdem_add_gdppc <- libdem_model_add_gdppc %>% tidy() %>% mutate(model = "add_gdppc") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_add_gdppc, by = "model") %>% left_join(libdem_mcfadden_add_gdppc, by = "model")
libdem_add_wto <- libdem_model_add_wto %>% tidy() %>% mutate(model = "add_wto") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_add_wto, by = "model") %>% left_join(libdem_mcfadden_add_wto, by = "model")
libdem_add_gravity <- libdem_model_add_gravity %>% tidy() %>% mutate(model = "add_gravity") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(libdem_n_obs_add_gravity, by = "model") %>% left_join(libdem_mcfadden_add_gravity, by = "model")
libdem_add_exports <- libdem_model_add_exports %>% tidy() %>% mutate(model = "add_exports") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_add_exports, by = "model") %>% left_join(libdem_mcfadden_add_exports, by = "model")

all_results_libdem <- rbind(libdem_base, libdem_add_gdppc, libdem_add_wto, libdem_add_gravity, libdem_add_exports)



#### Table A3: Average polyarchy democracy measurement (instead of share of democratic members as IV) 


polyarchy_model_base <- polr(as.factor(tradem_index) ~ mean_v2x_polyarchy + depth_index,
                             data = treaty_data,
                             method = c("logistic"))


polyarchy_model_add_gdppc <- polr(as.factor(tradem_index) ~ mean_v2x_polyarchy + 
                                    depth_index + log(mean_gdppc),
                                  data = treaty_data,
                                  method = c("logistic"))

polyarchy_model_add_wto <- polr(as.factor(tradem_index) ~ mean_v2x_polyarchy + 
                                  depth_index + log(mean_gdppc) + mean_wto_gatt,
                                data = treaty_data,
                                method = c("logistic")) 

polyarchy_model_add_gravity <- polr(as.factor(tradem_index) ~ mean_v2x_polyarchy + 
                                      depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                      mean_comleg_posttrans ,
                                    data = treaty_data,
                                    method = c("logistic")) 


polyarchy_model_add_exports <- polr(as.factor(tradem_index) ~ mean_v2x_polyarchy + 
                                      depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                      mean_comleg_posttrans + log(mean_exports),
                                    data = treaty_data,
                                    method = c("logistic"))

coeftest(polyarchy_model_base)
coeftest(polyarchy_model_add_gdppc)
coeftest(polyarchy_model_add_wto)
coeftest(polyarchy_model_add_gravity)
coeftest(polyarchy_model_add_exports)

### GET N OBS

polyarchy_n_obs_base <- polyarchy_model_base %>% glance() %>% select(nobs) %>% mutate(model = "base")
polyarchy_n_obs_add_gdppc <- polyarchy_model_add_gdppc %>% glance() %>% select(nobs) %>% mutate(model = "add_gdppc")
polyarchy_n_obs_add_wto <- polyarchy_model_add_wto %>% glance() %>% select(nobs) %>% mutate(model = "add_wto")
polyarchy_n_obs_add_gravity <- polyarchy_model_add_gravity %>% glance() %>% select(nobs) %>% mutate(model = "add_gravity")
polyarchy_n_obs_add_exports <- polyarchy_model_add_exports %>% glance() %>% select(nobs) %>% mutate(model = "add_exports")


### GET MCFADDEN R SQUARED

polyarchy_model_null <- polr(as.factor(tradem_index) ~ 1, data = treaty_data,
                             method = c("logistic"))

polyarchy_mcfadden_base <- as.data.frame(list(mcfadden = round(1 - (logLik(polyarchy_model_base)/logLik(polyarchy_model_null)),2))) %>% mutate(model = "base")
polyarchy_mcfadden_add_gdppc <- as.data.frame(list(mcfadden = round(1 - (logLik(polyarchy_model_add_gdppc)/logLik(polyarchy_model_null)),2))) %>% mutate(model = "add_gdppc")
polyarchy_mcfadden_add_wto <- as.data.frame(list(mcfadden = round(1 - (logLik(polyarchy_model_add_wto)/logLik(polyarchy_model_null)),2))) %>% mutate(model = "add_wto")
polyarchy_mcfadden_add_gravity <- as.data.frame(list(mcfadden = round(1 - (logLik(polyarchy_model_add_gravity)/logLik(polyarchy_model_null)),2))) %>% mutate(model = "add_gravity")
polyarchy_mcfadden_add_exports <- as.data.frame(list(mcfadden = round(1 - (logLik(polyarchy_model_add_exports)/logLik(polyarchy_model_null)),2))) %>% mutate(model = "add_exports")


### PASTE ALL RESULTS

polyarchy_base <- polyarchy_model_base %>% tidy() %>% mutate(model = "base") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_base, by = "model") %>% left_join(polyarchy_mcfadden_base, by = "model")
polyarchy_add_gdppc <- polyarchy_model_add_gdppc %>% tidy() %>% mutate(model = "add_gdppc") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_add_gdppc, by = "model") %>% left_join(polyarchy_mcfadden_add_gdppc, by = "model")
polyarchy_add_wto <- polyarchy_model_add_wto %>% tidy() %>% mutate(model = "add_wto") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_add_wto, by = "model") %>% left_join(polyarchy_mcfadden_add_wto, by = "model")
polyarchy_add_gravity <- polyarchy_model_add_gravity %>% tidy() %>% mutate(model = "add_gravity") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(polyarchy_n_obs_add_gravity, by = "model") %>% left_join(polyarchy_mcfadden_add_gravity, by = "model")
polyarchy_add_exports <- polyarchy_model_add_exports %>% tidy() %>% mutate(model = "add_exports") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_add_exports, by = "model") %>% left_join(polyarchy_mcfadden_add_exports, by = "model")

all_results_polyarchy <- rbind(polyarchy_base, polyarchy_add_gdppc, polyarchy_add_wto, polyarchy_add_gravity, polyarchy_add_exports)




#-------------------------------------------------------------------------------------#

####                          TABLE 6: DV = CATEGORY INDICES                        ####

#-------------------------------------------------------------------------------------#


general_model <- polr(as.factor(general_index) ~ share_dem_members + 
                        depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                        mean_comleg_posttrans + log(mean_exports),
                      data = treaty_data,
                      method = c("logistic"))



demprom_model <- polr(as.factor(democracypromotion_index) ~ share_dem_members + 
                        depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                        mean_comleg_posttrans + log(mean_exports),
                      data = treaty_data,
                      method = c("logistic"))


individualrights_model <- polr(as.factor(individualrights_index) ~ share_dem_members + 
                                 depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                 mean_comleg_posttrans + log(mean_exports),
                               data = treaty_data,
                               method = c("logistic"))



transparency_model <- polr(as.factor(transparency_index) ~ share_dem_members + 
                             depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                             mean_comleg_posttrans + log(mean_exports),
                           data = treaty_data,
                           method = c("logistic"))


stakeholderparticipation_model <- polr(as.factor(stakeholderparticipation_index) ~ share_dem_members + 
                                         depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                         mean_comleg_posttrans + log(mean_exports),
                                       data = treaty_data,
                                       method = c("logistic"))

policyspace_model <- polr(as.factor(policyspace_index) ~ share_dem_members + 
                            depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                            mean_comleg_posttrans + log(mean_exports),
                          data = treaty_data,
                          method = c("logistic"))



coeftest(general_model)
coeftest(demprom_model)
coeftest(individualrights_model)
coeftest(transparency_model)
coeftest(stakeholderparticipation_model)
coeftest(policyspace_model)



### GET N OBS

n_obs_general <- general_model %>% glance() %>% select(nobs) %>% mutate(model = "general")
n_obs_individualrights <- individualrights_model %>% glance() %>% select(nobs) %>% mutate(model = "individualrights")
n_obs_transparency <- transparency_model %>% glance() %>% select(nobs) %>% mutate(model = "transparency")
n_obs_stakeholderparticipation <- stakeholderparticipation_model %>% glance() %>% select(nobs) %>% mutate(model = "stakeholderparticipation")
n_obs_policyspace <- policyspace_model %>% glance() %>% select(nobs) %>% mutate(model = "policyspace")


### GET MCFADDEN R SQUARED

general_null <- polr(as.factor(general_index) ~ 1, data = treaty_data,
                     method = c("logistic"))

individualrights_null <- polr(as.factor(individualrights_index) ~ 1, data = treaty_data,
                              method = c("logistic"))

transparency_null <- polr(as.factor(transparency_index) ~ 1, data = treaty_data,
                          method = c("logistic"))

stakeholderparticipation_null <- polr(as.factor(stakeholderparticipation_index) ~ 1, data = treaty_data,
                                      method = c("logistic"))

policyspace_null <- polr(as.factor(policyspace_index) ~ 1, data = treaty_data,
                         method = c("logistic"))



mcfadden_general <- as.data.frame(list(mcfadden = round(1 - (logLik(general_model)/logLik(general_null)),2))) %>% mutate(model = "general")
mcfadden_individualrights <- as.data.frame(list(mcfadden = round(1 - (logLik(individualrights_model)/logLik(individualrights_null)),2))) %>% mutate(model = "individualrights")
mcfadden_transparency <- as.data.frame(list(mcfadden = round(1 - (logLik(transparency_model)/logLik(transparency_null)),2))) %>% mutate(model = "transparency")
mcfadden_stakeholderparticipation <- as.data.frame(list(mcfadden = round(1 - (logLik(stakeholderparticipation_model)/logLik(stakeholderparticipation_null)),2))) %>% mutate(model = "stakeholderparticipation")
mcfadden_policyspace <- as.data.frame(list(mcfadden = round(1 - (logLik(policyspace_model)/logLik(policyspace_null)),2))) %>% mutate(model = "policyspace")


### PASTE ALL RESULTS

general <- general_model %>% tidy() %>% mutate(model = "general") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_general, by = "model") %>% left_join(mcfadden_general, by = "model")
individualrights <- individualrights_model %>% tidy() %>% mutate(model = "individualrights") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_individualrights, by = "model") %>% left_join(mcfadden_individualrights, by = "model")
transparency <- transparency_model %>% tidy() %>% mutate(model = "transparency") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_transparency, by = "model") %>% left_join(mcfadden_transparency, by = "model")
stakeholderparticipation <- stakeholderparticipation_model %>% tidy() %>% mutate(model = "stakeholderparticipation") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(n_obs_stakeholderparticipation, by = "model") %>% left_join(mcfadden_stakeholderparticipation, by = "model")
policyspace <- policyspace_model %>% tidy() %>% mutate(model = "policyspace") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(n_obs_policyspace, by = "model") %>% left_join(mcfadden_policyspace, by = "model")

all_results_categories <- rbind(general, individualrights, transparency, stakeholderparticipation, policyspace)


#-------------------------------------------------------------------------------------#

####                    ROBUSTNESS CHECKS FOR TABLE 6                              ####

#-------------------------------------------------------------------------------------#



#### Table A2: Average liberal democracy measurement (instead of share of democratic members as IV) 


general_model_libdem <- polr(as.factor(general_index) ~ mean_v2x_libdem + 
                               depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                               mean_comleg_posttrans + log(mean_exports),
                             data = treaty_data,
                             method = c("logistic"))



demprom_model_libdem <- polr(as.factor(democracypromotion_index) ~ mean_v2x_libdem + 
                               depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                               mean_comleg_posttrans + log(mean_exports),
                             data = treaty_data,
                             method = c("logistic"))


individualrights_model_libdem <- polr(as.factor(individualrights_index) ~ mean_v2x_libdem + 
                                        depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                        mean_comleg_posttrans + log(mean_exports),
                                      data = treaty_data,
                                      method = c("logistic"))


transparency_model_libdem <- polr(as.factor(transparency_index) ~ mean_v2x_libdem + 
                                    depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                    mean_comleg_posttrans + log(mean_exports),
                                  data = treaty_data,
                                  method = c("logistic"))


stakeholderparticipation_model_libdem <- polr(as.factor(stakeholderparticipation_index) ~ mean_v2x_libdem + 
                                                depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                                mean_comleg_posttrans + log(mean_exports),
                                              data = treaty_data,
                                              method = c("logistic"))

policyspace_model_libdem <- polr(as.factor(policyspace_index) ~ mean_v2x_libdem + 
                                   depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                   mean_comleg_posttrans + log(mean_exports),
                                 data = treaty_data,
                                 method = c("logistic"))



coeftest(general_model_libdem)
coeftest(demprom_model_libdem)
coeftest(individualrights_model_libdem)
coeftest(transparency_model_libdem)
coeftest(stakeholderparticipation_model_libdem)
coeftest(policyspace_model_libdem)


### GET N OBS

libdem_n_obs_general <- general_model_libdem %>% glance() %>% select(nobs) %>% mutate(model = "general")
libdem_n_obs_individualrights <- individualrights_model_libdem %>% glance() %>% select(nobs) %>% mutate(model = "individualrights")
libdem_n_obs_transparency <- transparency_model_libdem %>% glance() %>% select(nobs) %>% mutate(model = "transparency")
libdem_n_obs_stakeholderparticipation <- stakeholderparticipation_model_libdem %>% glance() %>% select(nobs) %>% mutate(model = "stakeholderparticipation")
libdem_n_obs_policyspace <- policyspace_model_libdem %>% glance() %>% select(nobs) %>% mutate(model = "policyspace")


### GET MCFADDEN R SQUARED

libdem_general_null <- polr(as.factor(general_index) ~ 1, data = treaty_data,
                            method = c("logistic"))

libdem_individualrights_null <- polr(as.factor(individualrights_index) ~ 1, data = treaty_data,
                                     method = c("logistic"))

libdem_transparency_null <- polr(as.factor(transparency_index) ~ 1, data = treaty_data,
                                 method = c("logistic"))

libdem_stakeholderparticipation_null <- polr(as.factor(stakeholderparticipation_index) ~ 1, data = treaty_data,
                                             method = c("logistic"))

libdem_policyspace_null <- polr(as.factor(policyspace_index) ~ 1, data = treaty_data,
                                method = c("logistic"))



libdem_mcfadden_general <- as.data.frame(list(mcfadden = round(1 - (logLik(general_model_libdem)/logLik(libdem_general_null)),2))) %>% mutate(model = "general")
libdem_mcfadden_individualrights <- as.data.frame(list(mcfadden = round(1 - (logLik(individualrights_model_libdem)/logLik(libdem_individualrights_null)),2))) %>% mutate(model = "individualrights")
libdem_mcfadden_transparency <- as.data.frame(list(mcfadden = round(1 - (logLik(transparency_model_libdem)/logLik(libdem_transparency_null)),2))) %>% mutate(model = "transparency")
libdem_mcfadden_stakeholderparticipation <- as.data.frame(list(mcfadden = round(1 - (logLik(stakeholderparticipation_model_libdem)/logLik(libdem_stakeholderparticipation_null)),2))) %>% mutate(model = "stakeholderparticipation")
libdem_mcfadden_policyspace <- as.data.frame(list(mcfadden = round(1 - (logLik(policyspace_model_libdem)/logLik(libdem_policyspace_null)),2))) %>% mutate(model = "policyspace")


### PASTE ALL RESULTS

libdem_general <- general_model_libdem %>% tidy() %>% mutate(model = "general") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_general, by = "model") %>% left_join(libdem_mcfadden_general, by = "model")
libdem_individualrights <- individualrights_model_libdem %>% tidy() %>% mutate(model = "individualrights") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_individualrights, by = "model") %>% left_join(libdem_mcfadden_individualrights, by = "model")
libdem_transparency <- transparency_model_libdem %>% tidy() %>% mutate(model = "transparency") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_transparency, by = "model") %>% left_join(libdem_mcfadden_transparency, by = "model")
libdem_stakeholderparticipation <- stakeholderparticipation_model_libdem %>% tidy() %>% mutate(model = "stakeholderparticipation") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(libdem_n_obs_stakeholderparticipation, by = "model") %>% left_join(libdem_mcfadden_stakeholderparticipation, by = "model")
libdem_policyspace <- policyspace_model_libdem %>% tidy() %>% mutate(model = "policyspace") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(libdem_n_obs_policyspace, by = "model") %>% left_join(libdem_mcfadden_policyspace, by = "model")

all_results_categories_libdem <- rbind(libdem_general, libdem_individualrights, libdem_transparency, libdem_stakeholderparticipation, libdem_policyspace)



#### Table A4: Average polyarchy democracy measurement (instead of share of democratic members as IV) 


general_model_polyarchy <- polr(as.factor(general_index) ~ mean_v2x_polyarchy + 
                        depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                      mean_comleg_posttrans + log(mean_exports),
                      data = treaty_data,
                      method = c("logistic"))



demprom_model_polyarchy <- polr(as.factor(democracypromotion_index) ~ mean_v2x_polyarchy + 
                        depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                        mean_comleg_posttrans + log(mean_exports),
                      data = treaty_data,
                      method = c("logistic"))


individualrights_model_polyarchy <- polr(as.factor(individualrights_index) ~ mean_v2x_polyarchy + 
                                 depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                 mean_comleg_posttrans + log(mean_exports),
                               data = treaty_data,
                               method = c("logistic"))



transparency_model_polyarchy <- polr(as.factor(transparency_index) ~ mean_v2x_polyarchy + 
                             depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                             mean_comleg_posttrans + log(mean_exports),
                           data = treaty_data,
                           method = c("logistic"))


stakeholderparticipation_model_polyarchy <- polr(as.factor(stakeholderparticipation_index) ~ mean_v2x_polyarchy + 
                                         depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                                         mean_comleg_posttrans + log(mean_exports),
                                       data = treaty_data,
                                       method = c("logistic"))

policyspace_model_polyarchy <- polr(as.factor(policyspace_index) ~ mean_v2x_polyarchy + 
                            depth_index + log(mean_gdppc) + mean_wto_gatt + log(mean_distw) +
                            mean_comleg_posttrans + log(mean_exports),
                          data = treaty_data,
                          method = c("logistic"))



coeftest(general_model_polyarchy)
coeftest(demprom_model_polyarchy)
coeftest(individualrights_model_polyarchy)
coeftest(transparency_model_polyarchy)
coeftest(stakeholderparticipation_model_polyarchy)
coeftest(policyspace_model_polyarchy)



### GET N OBS

polyarchy_n_obs_general <- general_model_polyarchy %>% glance() %>% select(nobs) %>% mutate(model = "general")
polyarchy_n_obs_individualrights <- individualrights_model_polyarchy %>% glance() %>% select(nobs) %>% mutate(model = "individualrights")
polyarchy_n_obs_transparency <- transparency_model_polyarchy %>% glance() %>% select(nobs) %>% mutate(model = "transparency")
polyarchy_n_obs_stakeholderparticipation <- stakeholderparticipation_model_polyarchy %>% glance() %>% select(nobs) %>% mutate(model = "stakeholderparticipation")
polyarchy_n_obs_policyspace <- policyspace_model_polyarchy %>% glance() %>% select(nobs) %>% mutate(model = "policyspace")


### GET MCFADDEN R SQUARED

polyarchy_general_null <- polr(as.factor(general_index) ~ 1, data = treaty_data,
                               method = c("logistic"))

polyarchy_individualrights_null <- polr(as.factor(individualrights_index) ~ 1, data = treaty_data,
                                        method = c("logistic"))

polyarchy_transparency_null <- polr(as.factor(transparency_index) ~ 1, data = treaty_data,
                                    method = c("logistic"))

polyarchy_stakeholderparticipation_null <- polr(as.factor(stakeholderparticipation_index) ~ 1, data = treaty_data,
                                                method = c("logistic"))

polyarchy_policyspace_null <- polr(as.factor(policyspace_index) ~ 1, data = treaty_data,
                                   method = c("logistic"))



polyarchy_mcfadden_general <- as.data.frame(list(mcfadden = round(1 - (logLik(general_model_polyarchy)/logLik(polyarchy_general_null)),2))) %>% mutate(model = "general")
polyarchy_mcfadden_individualrights <- as.data.frame(list(mcfadden = round(1 - (logLik(individualrights_model_polyarchy)/logLik(polyarchy_individualrights_null)),2))) %>% mutate(model = "individualrights")
polyarchy_mcfadden_transparency <- as.data.frame(list(mcfadden = round(1 - (logLik(transparency_model_polyarchy)/logLik(polyarchy_transparency_null)),2))) %>% mutate(model = "transparency")
polyarchy_mcfadden_stakeholderparticipation <- as.data.frame(list(mcfadden = round(1 - (logLik(stakeholderparticipation_model_polyarchy)/logLik(polyarchy_stakeholderparticipation_null)),2))) %>% mutate(model = "stakeholderparticipation")
polyarchy_mcfadden_policyspace <- as.data.frame(list(mcfadden = round(1 - (logLik(policyspace_model_polyarchy)/logLik(polyarchy_policyspace_null)),2))) %>% mutate(model = "policyspace")


### PASTE ALL RESULTS

polyarchy_general <- general_model_polyarchy %>% tidy() %>% mutate(model = "general") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_general, by = "model") %>% left_join(polyarchy_mcfadden_general, by = "model")
polyarchy_individualrights <- individualrights_model_polyarchy %>% tidy() %>% mutate(model = "individualrights") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_individualrights, by = "model") %>% left_join(polyarchy_mcfadden_individualrights, by = "model")
polyarchy_transparency <- transparency_model_polyarchy %>% tidy() %>% mutate(model = "transparency") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_transparency, by = "model") %>% left_join(polyarchy_mcfadden_transparency, by = "model")
polyarchy_stakeholderparticipation <- stakeholderparticipation_model_polyarchy %>% tidy() %>% mutate(model = "stakeholderparticipation") %>% mutate(across(where(is.numeric), round, 2))  %>% left_join(polyarchy_n_obs_stakeholderparticipation, by = "model") %>% left_join(polyarchy_mcfadden_stakeholderparticipation, by = "model")
polyarchy_policyspace <- policyspace_model_polyarchy %>% tidy() %>% mutate(model = "policyspace") %>% mutate(across(where(is.numeric), round, 2)) %>% left_join(polyarchy_n_obs_policyspace, by = "model") %>% left_join(polyarchy_mcfadden_policyspace, by = "model")

all_results_categories_polyarchy <- rbind(polyarchy_general, polyarchy_individualrights, polyarchy_transparency, polyarchy_stakeholderparticipation, polyarchy_policyspace)



